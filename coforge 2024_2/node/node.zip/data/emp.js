const employee=[
    {
        eid: 100001,
        name:'suman kumar',
        salary: 25000,
        dob:'10-11-2001'
    },
    {
        eid: 100002,
        name:'azad kumar',
        salary: 29000,
        dob:'10-11-2012'
    },
    {
        eid: 100003,
        name:'smita choudhary',
        salary: 75000,
        dob:'10-11-1998'
    }
];
module.exports=employee;